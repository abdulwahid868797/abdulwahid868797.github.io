 // main document ready function to check if dom is loaded fully or not
  $( document ).ready(function() {
//facebook token using graph api
    var myFacebookToken ='EAACEdEose0cBAMuYsTEfap2QfILPNE4myOD3X8FFBhF5lG37iYFhYfnMZAgBzlAvFH2962bpIygZCSZCZBGi04Ydg8CZAmN61RksTIOIRMbZBQ5ViJaGxgJ6ER71T5hrTWdH0kRTBPPLiX2nSoVxBz9QAdprkZC3qNakZA4cZAZBad2j2BSZAAqEMMZACdyXta6pqRezydrWL71kZBwZDZD'
  //geting my facebook  info using graph api and ajax
    function getFacebookInfo(){
      $.ajax('https://graph.facebook.com/me?fields=id,email,hometown,name,posts&access_token='+myFacebookToken,{
          success : function(response)
               {
                    console.log(response);
                    console.log(typeof(response));
                    $("#myEmail").text(response.email);
                    $("#myName").text(response.name);
                    $("#myProfileId").html('<a target="blank" href="https://facebook.com/'+response.id+'">https://facebook.com/'+response.id+'</a>');
                    $("#myHomeTown").text(response.hometown.name);
                   //geting recent posts on facebook posted by me 
                    function Posts()
                    {
                       if(response.posts.data!=undefined && response.posts.data!=null)
                      {
                            $("#posts1").text(response.posts.data[1].story);
                            $("#posts2").text(response.posts.data[2].story);
                            $("#posts3").text(response.posts.data[3].story);
                            $("#posts4").text(response.posts.data[4].story);     
                      }
                   } 
                  Posts();
                }
            }//end argument list......
        );// end ajax call 
    }// end get facebook info

    $("#facebookBtn").on('click',getFacebookInfo)
    });